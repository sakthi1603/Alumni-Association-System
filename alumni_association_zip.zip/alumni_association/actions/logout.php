<?php
if(isset($_GET['logout'])){
    session_abort();
    header("Location: ../home/index.php");
    exit;
}
?>