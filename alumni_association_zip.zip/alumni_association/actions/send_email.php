<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

function send_email($subject, $message, $img){
    include ('../home/db_connection.php');
    try {
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'sathiyaseelan1603@gmail.com';
        $mail->Password = 'fsyclkixdzrhdogf';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('sathiyaseelan1603@gmail.com');


        // SQL query to retrieve email IDs from the database
        $sql = "SELECT email FROM alumni";
        $result = $con->query($sql);


        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Iterate through each row
            while($row = $result->fetch_assoc()) {
                $to_email = $row['email']; // Get the email ID from the current row

                // Clear all recipients and add the new recipient
                $mail->clearAllRecipients();
                $mail->addAddress($to_email);

                $image_path = "$img"; // Change this to the path of your image file
                $image_data = file_get_contents($image_path);
                $image_mime = finfo_buffer(finfo_open(), $image_data, FILEINFO_MIME_TYPE);

                $mail->isHTML(true);
                $mail->Subject = $subject;

                $contents = 
                    "<h1>$subject</h1>
                     <img src='$img' alt='banner'>
                     <p>$message</p>
                    ";

                $mail->msgHTML($contents, __DIR__);

                $mail->send();

            }
            echo "<script>alert('Notification sent to the alumni');</script>";

        } 
        else {
            echo "No email IDs found in the database.";
        }

        // Close database connection
        $con->close();
    } catch (Exception $e) {
        echo "<script>alert('Error sending email: " . $mail->ErrorInfo . "');</script>";
    }
}
?>
