<?php include ('../home/db_connection.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="search.css?v=<?php echo time();?>"> -->
    <title>Alumni Search</title>
    <style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    list-style: none;
    text-decoration: none;
    border: none;
    outline: none;
    font-family: 'Open Sans', sans-serif;
    scroll-behavior: smooth;
}

:root {
    --space-cadet: #2b2d42ff;
    --cool-gray: #8d99aeff;
    --gray-bg: #f9f9f9;
    --antiflash-white: #edf2f4ff;
    --red-pantone: #ef233cff;
    --fire-engine-red: #d90429ff;
}
.search-container {
    max-width: 95%;
    margin: 100px auto;
    background-color: var(--antiflash-white);
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
    display: flex;
    flex-direction: column;
    align-items: center;
}

.search-container h1 {
    text-align: center;
    color: var(--red-pantone);
    margin-bottom: 20px;
}

.form-group {
    display: flex;
    justify-content: space-between;
    width: 100%;
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
}

.form-group input, .form-group select {
    padding: 10px;
    border: 1px solid var(--cool-gray);
    border-radius: 4px;
}

#name {
    flex: 2;
    margin-right: 10px;
}

#department, #batch {
    flex: 1;
    margin-right: 10px;
}

.form-group button {
    flex: 0.5;
    padding: 10px;
    border: 1.5px solid var(--space-cadet);
    background-color: white;
    color: var(--space-cadet);
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
}

.form-group button:hover {
    background-color: var(--space-cadet);
    color: var(--antiflash-white);
}

.results-container {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-top: 20px;
    margin-left: 35px;
    width: 100%;
}

.result-card {
    background-color: var(--gray-bg);
    border: 1px solid var(--red-pantone);
    border-radius: 8px;
    padding: 15px;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    width: calc(33.33% - 20px);
    box-sizing: border-box;
}

.result-card .profile-picture {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    margin-right: 20px;
}

.result-card .card-content {
    flex: 1;
}

.result-card h2 {
    color: var(--red-pantone);
    margin: 0 0 10px 0;
}

.result-card p {
    margin: 5px 0;
}

.no-results {
    text-align: center;
    color: var(--fire-engine-red);
    width: 100%;
}
    </style>
</head>
<body>
    <div class="search-container">
        <h1>Search Staff</h1>
        <form method="post">
            <div class="form-group">
                <input type="text" id="name" name="name" placeholder="Enter name">
                <select id="department" name="department">
                    <option value="">All Departments</option>
                    <!-- Options will be populated by PHP -->
                    <?php
                         $sql = "SELECT * FROM course";
                         $res = mysqli_query($con, $sql);
                         if(mysqli_num_rows($res)>0){
                             foreach($res as $row){
                     ?>
                             <option value="<?php echo $row['id'];?>"><?php echo $row['course'];?> <?php echo $row['branch'];?></option>
                     <?php
                             }
                         }
                     ?>
                </select>
                <button type="submit" name="search">Search</button>
            </div>
        </form>
            <!-- Search results will be displayed here -->
        </div>
<?php
    if(isset($_POST['search'])){
        $name = isset($_POST['name']) ? $_POST['name'] : '';
        $department = isset($_POST['department']) ? $_POST['department'] : '';

        
        $sql = "SELECT * FROM staff WHERE 1=1";
        
        if ($name != '') {
            $sql .= " AND name LIKE '%" . $con->real_escape_string($name) . "%'";
        }
        if ($department != '') {
            $sql .= " AND course_id = '" . $con->real_escape_string($department) . "'";
        }
    }
    else{
        $sql = "SELECT * FROM staff";
    }
        $result = $con->query($sql);

        echo '<div class="results-container">';
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Fetching course details based on department ID
                $course_sql = "SELECT * FROM course";
                $course_result = $con->query($course_sql);
                $course = $course_result->fetch_array();
        
                echo '<div class="result-card">';
                echo '<img src="../user/staff_profiles/' . $row['profile'] . '" alt="'. $row['profile']. '" class="profile-picture">';
                echo '<div class="card-content">';
                echo '<h2>' . $row['name'] . '</h2>';
                echo '<p><strong>Department:</strong> ' . $course['1'] . ' ' . $course['2'] . '</p>';
                echo '<p><strong>Contact:</strong> ' . $row['contact'] . '</p>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p class="no-results">No results found</p>';
        }
        echo '</div>';
        
?>
</body>
</html>
