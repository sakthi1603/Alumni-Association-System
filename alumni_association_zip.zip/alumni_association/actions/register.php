<?php
    include("../home/db_connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="register.css?v=<?php echo time();?>">
    <title>Registration Form</title>
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        <form method="POST" enctype ="multipart/form-data">
            <label for="fullname">Full Name:</label>
            <input type="text" id="fullname" name="fullname" required>
            
            <label for="gender">Gender:</label>
            <select name="gender" id="gender" required>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="department">Department:</label>
            <select name="department" id="department" required>
                <option value="">Select Department</option>
                <?php
                    $sql = "SELECT * FROM course";
                    $res = mysqli_query($con, $sql);
                    if(mysqli_num_rows($res)>0){
                        foreach($res as $row){
                ?>
                        <option value="<?php echo $row['id'];?>"><?php echo $row['course'];?> <?php echo $row['branch'];?></option>
                <?php
                        }
                    }
                ?>
            </select>
            
            <label for="contact">Contact No:</label>
            <input type="text" id="contact" name="contact" required>
            
            <label for="email">Email ID:</label>
            <input type="email" id="email" name="email" required>

            <label for="maritalstatus">Marital Status:</label>
            <select name="maritalstatus" id="maritalstatus" required>
                <option value="">Select Marital Status</option>
                <option value="single">Single</option>
                <option value="married">Married</option>
                <option value="divorced">Divorced</option>
                <option value="widowed">Widowed</option>
            </select>

            <label for="address">Address:</label>
            <textarea id="address" name="address" required></textarea>

            <label for="usertype">Type of User:</label> <br><br>
            <input type="radio" name="user" id="user" onclick = "showDiv()" value='alumni'> Alumni
            <input type="radio" name="user" id="user" onclick = "hideDiv()" value='staff'> Staff <br><br>

            <fieldset id='hide'>
                <label for="registerno">Register No:</label>
                <input type="text" id="registerno" name="registerno">
                
                <label for="yearpassedout">Year Passed Out:</label>
                <input type="text" id="yearpassedout" name="yearpassedout">

                <label for="jobtitle">Current Job Title:</label>
                <input type="text" id="jobtitle" name="jobtitle">

                <label for="joblocation">Current Job Location:</label>
                <input type="text" id="joblocation" name="joblocation">
            </fieldset> <br>

            <label for="profilepic">Profile Picture:</label>
            <input type="file" id="profilepic" name="profilepic" accept="image/*" required> <br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <label for="confirmpassword">Confirm Password:</label>
            <input type="password" id="confirmpassword" name="confirmpassword" required>
            
            <input type="submit" value="Register" name="register">
            <p><span><a href="../home/index.php">Home</a></span> Already have account? <span><a href="./login.php">Login</a></span></p>
        </form>
    </div>
<script>
    function showDiv(){
        var div = document.getElementById('hide');
        var register = document.getElementById("registerno");
        var year = document.getElementById("yearpassedout");
        var title = document.getElementById("jobtitle");
        var location = document.getElementById("joblocation");

        register.required = true;
        year.required = true;
        title.required = true;
        location.required = true;

        div.style.display = "block";
    }
    function hideDiv(){
        var div = document.getElementById('hide');
        var register = document.getElementById("registerno");
        var year = document.getElementById("yearpassedout");
        var title = document.getElementById("jobtitle");
        var location = document.getElementById("joblocation");

        register.required = false;
        year.required = false;
        title.required = false;
        location.required = false;

        div.style.display = "none";
    }
</script>
<?php
    if(isset($_POST['register'])){
        $user = $_POST['user'];
        $fullname = $_POST['fullname'];
        $gender = $_POST['gender'];
        $department = $_POST['department'];
        $contact = $_POST['contact'];
        $email = $_POST['email'];
        $maritalstatus = $_POST['maritalstatus'];
        $address = $_POST['address'];
        $profilepic = $_FILES['profilepic']['name'];
        $tmp_name = $_FILES['profilepic']['tmp_name'];
        $password = $_POST['password'];
        $confirmpassword = $_POST['confirmpassword'];
        
        if($password != $confirmpassword){
            echo "<script>alert('Password and confirm password doesn't match!')</script>";
        }
        else{
            if($user == 'alumni'){
                $reg = $_POST['registerno'];
                $yearpassedout = $_POST['yearpassedout'];
                $jobtitle = $_POST['jobtitle'];
                $joblocation = $_POST['joblocation'];  
                
                $check = mysqli_query($con,"SELECT * FROM alumni WHERE id = '$reg'");
                if(mysqli_num_rows($check)>0){
                    echo "<script>alert('User exists!')</script>";
                    header("Location: ./login.php");
                }
                else{
                    move_uploaded_file($tmp_name,'../user/alumni_profiles/'.$profilepic);

                    $query = "INSERT INTO alumni VALUES($reg,'$fullname','$gender','$maritalstatus','$department','$contact','$email','$address','$yearpassedout','$jobtitle','$joblocation','$profilepic','$password')";
                    mysqli_query($con, $query);
                    echo "<script>
                    alert('Successfully registed!');
                    window.location.href='./login.php';
                    </script>";
                }
            }
            else{

                $check = mysqli_query($con,"SELECT * FROM staff WHERE email = '$email'");
                if(mysqli_num_rows($check)>0){
                    echo "<script>alert('User exists!')</script>";
                    header("Location: ./login.php");
                }
                else{
                    move_uploaded_file($tmp_name,'../user/staff_profiles/'.$profilepic);
                    $query = "INSERT INTO staff VALUES('','$fullname','$gender','$department','$contact','$email','$maritalstatus','$address','$profilepic','$password')";
                    mysqli_query($con, $query);
                    echo "<script>
                    alert('Successfully registed!');
                    window.location.href='./login.php';
                    </script>";
                }
            }
        }
    }
?>
</body>
</html>
