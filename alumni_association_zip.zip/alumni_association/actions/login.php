<?php
    include("../home/db_connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css?v=<?php echo time();?>">
    <title>Login Form</title>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder='Register no/email id' required>
            
            <label for="password">Password:</label>
            <div class="password-field">
                <input type="password" id="password" name = 'password' placeholder="Password" required>
                <span class="toggle-password" onclick="togglePasswordVisibility()"></span>
            </div>
            
            <label for="usertype">User Type:</label>
            <select name="usertype" id="usertype">
                <option value="alumni">Alumni</option>
                <option value="staff">Staff</option>
                <option value="admin">Admin</option>
            </select>
            
            <input type="submit" value="Login" name='login'>
            <p><span><a href="../home/index.php">Home</a></span> New user? <span><a href="./register.php">Register</a></span></p>
        </form>
    </div>
    <script>
        function togglePasswordVisibility() {
            var passwordField = document.getElementById("password");
            var toggleButton = document.querySelector(".toggle-password");

            if (passwordField.type === "text") {
                passwordField.type = "password";
                toggleButton.style.backgroundImage = "url('../images/eye-slash-icon.png')";
            } else {
                passwordField.type = "text";
                toggleButton.style.backgroundImage = "url('../images/eye-icon.png')";
            }
        }
    </script>
</body>
<?php
session_start();
    if(isset($_POST['login'])){
        $user = $_POST['usertype'];
        $name = $_POST['username'];
        $pass = $_POST['password'];
        if($user == 'alumni'){
            $query = "SELECT * FROM alumni WHERE id = '$name' AND password = '$pass'";
            $type = 'alumni';
        }
        else if($user == 'staff'){
            $query = "SELECT * FROM staff WHERE email = '$name' AND password = '$pass'";
            $type = 'staff';
        }
        else{
            $query = "SELECT * FROM admin WHERE name = '$name' AND password = '$pass'";
            $type = 'admin';
        }
        $sql = mysqli_query($con, $query);
        if(mysqli_num_rows($sql) == 0){
            echo "<script>alert('User does not exist!')</script>";
        }
        else{
            $row = mysqli_fetch_assoc($sql);
            $_SESSION['user'] = $row['name'];
            $_SESSION['profile'] = $row['profile'];
            $_SESSION['id'] = $row['id'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['type'] = $type;
            if($type == 'admin'){
                echo "<script>window.location.href='../admin/index.php';</script>";
            }
            // else if($type == 'staff'){
            //     echo "<script>window.location.href='./staff/staff_dashboard.php';</script>";
            // }
            else{
                echo "<script>window.location.href='../user/index.php';</script>";
            }
            echo "<script>alert('Logged in successfully!')</script>";
            // if($row['name'] == 'admin'){
            // }
        }
    }
?>
</html>
