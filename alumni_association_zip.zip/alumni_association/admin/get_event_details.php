<?php
include('../home/db_connection.php');
// Get job details from the database based on job ID passed via AJAX
$eventId = $_GET['id'];
$eventDetails = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM event WHERE id = $eventId")); // Fetch job details from your database based on $jobId

$idList = mysqli_query($con, "SELECT user_id FROM event_register WHERE event_id = $eventId"); 

if(mysqli_num_rows($idList)!=0){
    while($res = mysqli_fetch_array($idList)) {   
        $ids[] = $res['user_id'];   
    } 
    
    $members = $con->prepare("SELECT name, email FROM alumni WHERE id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")");
    $members->bind_param(str_repeat('i', count($ids)), ...$ids);
    
    $members->execute();
    
    $result = $members->get_result();
    $rows = [];
    
    // Fetch each row and store it in the array
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $eventDetails['members'] = $rows;
}
else{
    $eventDetails['members'] = [
        ['name' => 'none', 'email' => 'none']
    ];
}

// print_r($eventDetails);

echo json_encode($eventDetails);
?>