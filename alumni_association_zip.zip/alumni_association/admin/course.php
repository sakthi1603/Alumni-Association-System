<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Management</title>
    <link rel="stylesheet" href="course.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container">
        <div class="top-area">
            <h2>Add a New Course</h2>
            <form action="add_course.php" method="POST">
                <label for="course_name">Course Name:</label>
                <input type="text" id="course_name" name="c" required>

                <label for="branch">Branch:</label>
                <input type="text" id="branch" name="branch" required>

                <label for="duration">Duration (in years):</label>
                <input type="number" id="duration" name="duration" required>

                <button type="submit">Add Course</button>
            </form>
        </div>
        <div class="bottom-area">
            <h2>Available Courses</h2>
            <table>
                <thead>
                    <tr>
                        <th>Course Name</th>
                        <th>Branch</th>
                        <th>Duration (years)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include('../home/db_connection.php');
                    $sql = "SELECT * FROM course";
                    $result = mysqli_query($con, $sql);

                    if (mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['course'] . "</td>";
                            echo "<td>" . $row['branch'] . "</td>";
                            echo "<td>" . $row['duration'] . "</td>";
                            echo "<td><a href='delete_course.php?course-id=" . $row['id'] . "' class='delete-btn'>Delete</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No courses available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
