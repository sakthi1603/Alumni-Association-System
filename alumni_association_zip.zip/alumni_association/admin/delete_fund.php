<?php
    include('../home/db_connection.php');
    if(isset($_GET['fund-id'])){
        $id = $_GET['fund-id'];
        mysqli_query($con, "DELETE FROM fund WHERE id=$id");
        echo "<script>
        alert('fund Deleted!');
        window.location.href='./event.php';
        </script>";
    }
?>