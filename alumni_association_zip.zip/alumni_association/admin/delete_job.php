<?php
    include('../home/db_connection.php');
    if(isset($_GET['job-id'])){
        $id = $_GET['job-id'];
        mysqli_query($con, "DELETE FROM job WHERE id=$id");
        echo "<script>
        alert('Job Deleted!');
        window.location.href='./job.php';
        </script>";
    }
?>