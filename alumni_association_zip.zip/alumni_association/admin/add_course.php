<?php
    include("../home/db_connection.php");
    $branch = $_POST['branch'];
    $duration = $_POST['duration'];
    $course = $_POST['c'];
    $sql = "INSERT INTO course VALUES ('','$course', '$branch', '$duration')";

    // Execute the query
    if(mysqli_query($con, $sql)){
        echo "<script>alert('Course added successfully.')</script>";
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
    }
    
    echo "<script>
            window.location.href='./course.php';
            </script>";

    // Close connection
    mysqli_close($con);

?>

