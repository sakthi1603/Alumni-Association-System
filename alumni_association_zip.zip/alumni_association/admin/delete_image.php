<?php
    include('../home/db_connection.php');
    if(isset($_GET['image-id'])){
        $id = $_GET['image-id'];
        mysqli_query($con, "DELETE FROM gallery WHERE id=$id");
        echo "<script>
        alert('Image Deleted!');
        window.location.href='./gallery.php';
        </script>";
    }
?>