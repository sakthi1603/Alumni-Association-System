<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Board</title>
    <link rel="stylesheet" href="job.css?v<?php echo time();?>">
</head>
<body>
<div class="container">
        <div class="left-section">
            <h2>Post a New Job</h2>
            <form action="add_job.php" method="POST" enctype="multipart/form-data">
                <label for="job_title">Job Title:</label>
                <input type="text" id="job_title" name="job_title" required>
    
                <label for="event_description">Description:</label>
                <textarea id="job_description" name="job_description" rows="4" required></textarea><br>
                
                <label for="event_date">Held on:</label>
                <input type="date" id="date" name="job_date" required><br><br>
                
                <label for="event_location">Location:</label>
                <input type="text" id="job_location" name="job_location" required>
                
                <label for="event_timing">Qualification:</label>
                <input type="text" id="qualification" name="qualification" required>

                <label for="event_timing">Experience:</label>
                <input type="text" id="experience" name="experience" required>

                <label for="event_timing">Contact:</label>
                <input type="text" id="contact" name="contact" required>
                
                <label for="image_upload">Upload Image:</label>
                <input type="file" id="image_upload" name="image_upload" accept="image/*" required>

                <button type="submit">Publish Job</button>
            </form>
        </div>
        <div class="right-section">
            <h2>Open Positions</h2>
            <div class="search-container">
                <form id="searchForm" method="GET" action="">
                    <input type="text" id="search" name="search" placeholder="Search jobs...">
                    <button type="submit">Search</button>
                </form>
            </div>
            <div id="job-list" class='job-list'>
                <?php
                    include('../home/db_connection.php');
                    $searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

                    // Modify the SQL query based on the search query
                    if ($searchQuery) {
                        $sql = "SELECT * FROM job WHERE title LIKE '%" . mysqli_real_escape_string($con, $searchQuery) . "%' ORDER BY id DESC";
                    } else {
                        $sql = "SELECT * FROM job ORDER BY id DESC";
                    }
                    // $sql = "SELECT * FROM job ORDER BY id DESC";
                    $jobs = mysqli_query($con, $sql); // Fetch job listings from your database
                    if(mysqli_num_rows($jobs)>0){
                        foreach ($jobs as $job) {
                            $no = mysqli_num_rows(mysqli_query($con, "SELECT * FROM job_application WHERE job_id = ".$job['id']));

                            echo '<div class="job-card">';
                            echo '<h3>' . $job['title'] . '</h3>';
                            // Display job snippet
                            echo '<p>' . $job['description'] . '</p>';
                            echo '<p>' . $no . '</p>';
                            echo '<div class="buttons">';
                            echo "<a href='delete_job.php?job-id={$job['id']}' class='btn-delete'>Delete</a>";
                            // Pass job ID to JavaScript function to fetch job details
                            echo '<button onclick="openModal(' . $job['id'] . ')">View Details</button>';
                            echo '</div>';
                            echo '</div>';
                        }
                    }
                ?>
            </div>
        </div>
    </div>

    <!-- Modal window for job details -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Job Details</h2>
            <div id="jobDetails">
            <!-- Job details content will be populated dynamically via JavaScript -->
            </div>
        </div>
    </div>

    <script>
        function openModal(jobId) {
            var modal = document.getElementById("myModal");
            modal.style.display = "block";
            
            // Fetch job details from server using AJAX
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var jobDetails = JSON.parse(this.responseText);
                    // Populate modal with job details
                    document.getElementById("jobDetails").innerHTML =
                        '<h2>' + jobDetails.title + '</h2>' +
                        '<img src="../images/job_images/' + jobDetails.banner + '" alt="' + jobDetails.title + '">' +
                        '<p>' + jobDetails.description + '</p>' +
                        '<h3>Registered Members List</h3>' +
                        '<ul>' +
                        jobDetails.members.map(member =>
                            '<li>' + member.name + ' - Email: ' + member.email + '</li>'
                        ).join('') +
                        '</ul>';
                }
            };
            xhttp.open("GET", "get_job_details.php?id=" + jobId, true);
            xhttp.send();
        }

        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }

        function searchJobs() {
            var searchQuery = document.getElementById('search').value;
            // Add code to fetch and display filtered job listings based on the search query
            // You can use AJAX to fetch the data from the server and update the job list
        }
    </script>
</body>
</html>
