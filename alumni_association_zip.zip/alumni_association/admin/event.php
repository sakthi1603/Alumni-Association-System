<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Board</title>
    <link rel="stylesheet" href="event.css?v<?php echo time();?>">
</head>
<body>
<div class="container">
        <div class="left-section">
        <h2>Upcoming events</h2>
            <div class="search-container">
                <form id="searchForm" method="GET" action="">
                    <input type="text" id="search" name="search" placeholder="Search events...">
                    <button type="submit">Search</button>
                </form>
            </div>
        <div id="event-list" class='event-cards'>
                <?php
                    include('../home/db_connection.php');
                    $searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

                    // Modify the SQL query based on the search query
                    if ($searchQuery) {
                        $sql = "SELECT * FROM event WHERE title LIKE '%" . mysqli_real_escape_string($con, $searchQuery) . "%' ORDER BY id DESC";
                    } else {
                        $sql = "SELECT * FROM event ORDER BY id DESC";
                    }
                    // $sql = "SELECT * FROM job ORDER BY id DESC";
                    $events = mysqli_query($con, $sql); // Fetch job listings from your database
                    if(mysqli_num_rows($events)>0){
                        foreach ($events as $event) {
                            $no = mysqli_num_rows(mysqli_query($con, "SELECT * FROM event_register WHERE event_id = ".$event['id']));

                            echo '<div class="event-card">';
                            echo "<img src='../images/event_images/{$event['image']}' alt='Event Image' class='event-image'>";
                            echo '<h3>' . $event['title'] . '</h3>';
                            // Display job snippet
                            echo '<p>' . $event['description'] . '</p>';
                            echo '<p>Date & Time: '. $event['datetime'] . '</p>';
                            echo '<p>Registered: ' . $no . '</p>';
                            echo '<div class="buttons">';
                            echo "<a href='delete_event.php?event-id=".$event['id']."' class='btn-delete'>Delete</a>";
                            // Pass job ID to JavaScript function to fetch job details
                            echo '<button onclick="openModal(' . $event['id'] . ')">View Details</button>';
                            echo '</div>';
                            echo '</div>';
                        }
                    }
                ?>
            </div>
        </div>
        <div class="right-section">
        <h2>Post a New Event</h2>
            <form action="add_event.php" method="POST" enctype="multipart/form-data">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required>
                
                <label for="description">Description:</label>
                <textarea id="description" name="description" required></textarea>
                
                <label for="venue">Venue:</label>
                <input type="text" id="venue" name="venue" required>
                
                <label for="datetime">Date & Time:</label>
                <input type="datetime-local" id="datetime" name="datetime" required>
                
                <label for="image">Image Upload:</label>
                <input type="file" id="image" name="image">
                
                <button type="submit" class="btn-add-event">Add Event</button>
            </form>
            
        </div>
    </div>

    <!-- Modal window for job details -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Event Details</h2>
            <div id="eventDetails">
            <!-- Job details content will be populated dynamically via JavaScript -->
            </div>
        </div>
    </div>

    <script>
        function openModal(eventId) {
            var modal = document.getElementById("myModal");
            modal.style.display = "block";
            
            // Fetch job details from server using AJAX
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var eventDetails = JSON.parse(this.responseText);
                    // Populate modal with job details
                    document.getElementById("eventDetails").innerHTML =
                        '<h2>' + eventDetails.title + '</h2>' +
                        '<img src="../images/event_images/' + eventDetails.image + '" alt="' + eventDetails.title + '">' +
                        '<p>' + eventDetails.description + '</p>' +
                        '<h3>Registered Members List</h3>' +
                        '<ul>' +
                        eventDetails.members.map(member =>
                            '<li>' + member.name + ' - Email: ' + member.email + '</li>'
                        ).join('') +
                        '</ul>';
                }
            };
            xhttp.open("GET", "get_event_details.php?id=" + eventId, true);
            xhttp.send();
        }

        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }

    </script>
</body>
</html>
