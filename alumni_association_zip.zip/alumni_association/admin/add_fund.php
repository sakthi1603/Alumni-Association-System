<?php
    include('../home/db_connection.php');

    $title = $_POST['title'];
    $description = $_POST['description'];

    $sql = "INSERT INTO fund VALUES('', '$title', '$description')";
    mysqli_query($con, $sql);

    echo "<script>
        alert('Fund Posted!');
        window.location.href='./fund.php';
        </script>";
?>