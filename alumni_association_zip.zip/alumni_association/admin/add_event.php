<?php
    include("../home/db_connection.php");
    include('../actions/send_email.php');
    include('../actions/upload_img.php');

        $event_title = $_POST["title"];
        $event_description = $_POST["description"];
        $event_date = $_POST["datetime"];
        $event_location = $_POST["venue"];
            // Handle file upload
        $target_dir = "../images/event_images/";
        $image_name = $_FILES["image"]["name"];
        $tmp_name = $_FILES["image"]["tmp_name"];
        $size = $_FILES["image"]["size"];
        $image = upload_img($target_dir, $image_name, $tmp_name, $size);

        if($image == $image_name){
            $sql = "INSERT INTO event VALUES('','$event_title','$event_description','$event_date','$event_location','$image')";
            mysqli_query($con, $sql);
            
            $message = "<p>$event_description. <br> The event is on $event_date at $event_location</p>";

            echo "<script>
            alert('Event Added!');
            </script>";

            send_email($event_title, $message, "../images/event_images/$image");
            
            echo "<script>
            window.location.href='./event.php';
            </script>";
        }
        else{
            echo "<script>
            alert('$image');
            window.location.href='./event.php';
            </script>";
        }

?>