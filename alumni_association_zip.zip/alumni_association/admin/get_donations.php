<?php
include('../home/db_connection.php');
// Get job details from the database based on job ID passed via AJAX
$fundId = $_GET['id'];
$donationDetails = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM fund WHERE id = $fundId")); // Fetch job details from your database based on $jobId

$idList = mysqli_query($con, "SELECT user_id FROM donations WHERE fund_id = $fundId"); 

if(mysqli_num_rows($idList)!=0){
    while($res = mysqli_fetch_array($idList)) {   
        $ids[] = $res['user_id'];   
    } 
    
    $members = $con->prepare("SELECT name, email FROM alumni WHERE id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")");
    $members->bind_param(str_repeat('i', count($ids)), ...$ids);
    
    $members->execute();
    
    $result = $members->get_result();
    $rows = [];
    
    // Fetch each row and store it in the array
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $donationDetails['members'] = $rows;
}
else{
    $donationDetails['members'] = [
        ['name' => 'none', 'email' => 'none']
    ];
}

// print_r($eventDetails);

echo json_encode($donationDetails);
?>