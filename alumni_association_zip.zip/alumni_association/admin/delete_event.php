<?php
    include('../home/db_connection.php');
    if(isset($_GET['event-id'])){
        $id = $_GET['event-id'];
        mysqli_query($con, "DELETE FROM event WHERE id=$id");
        echo "<script>
        alert('Event Deleted!');
        window.location.href='./event.php';
        </script>";
    }
?>