<?php
include("../home/db_connection.php");
// Function to get count from the database
function getCount($tableName) {
    global $con; // Assuming $conn is your database connection object

    // Query to get count
    $sql = "SELECT COUNT(*) AS count FROM $tableName";
    $result = mysqli_query($con, $sql);

    // Check if query was successful
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        return $row['count'];
    } else {
        return 0;
    }
}
$totalDonation = 0;
    $query = "SELECT SUM(amount) AS total_amount FROM donations";
    $result = mysqli_query($con, $query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $totalDonation = $row['total_amount'];
    }

// Example usage
$adminCount = getCount('admin');
$alumniCount = getCount('alumni');
$staffCount = getCount('staff');
$courseCount = getCount('course');
$eventCount = getCount('event');
$jobCount = getCount('job');
$fundCount = getCount('fund');
$galleryCount = getCount('gallery'); // Example number for gallery items, replace with your logic or data

// Close database connection (optional, if not used globally)
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

     <style>
:root {
    --space-cadet: #2b2d42ff;
    --cool-gray: #8d99aeff;
    --gray-bg: #f9f9f9;
    --antiflash-white: #edf2f4ff;
    --red-pantone: #ef233cff;
    --fire-engine-red: #d90429ff;
}

.container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    padding: 7px;
}

.card {
    width: 120px;
    height: 140px;
    background-color: var(--antiflash-white);
    padding: 20px;
    margin: 10px;
    text-align: center;
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5); /* Box shadow for floating effect */
    transition: transform 0.3s ease-in-out; /* Smooth transition for floating effect */
}

.card:hover {
    transform: translateY(-5px); /* Move card up slightly on hover */
}

.card i {
    font-size: 3em; /* Larger icon size */
    color: var(--space-cadet);
}

.card h2 {
    margin-top: 10px;
    color: var(--red-pantone);
}

.card p {
    color: var(--space-cadet);
    font-size: 25px;
    padding: 2px 10px;
    border-radius: 20px;
}

.fund-card, .job-card, .event-card, .gallery-card {
    width: calc(50% - 60px); /* Half width for two cards per row with gap */
    height: 130px;
    background-color: var(--gray-bg);
    padding: 10px 20px;
    margin-top: 15px;
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5); /* Box shadow for floating effect */
    transition: transform 0.3s ease-in-out; /* Smooth transition for floating effect */
    display: flex;
    align-items: center;
    justify-content: space-between; /* Align items with space in between */
}

.fund-card:hover, .job-card:hover, .event-card:hover, .gallery-card:hover {
    transform: translateY(-5px); /* Move card up slightly on hover */
}

.fund-card i, .job-card i, .event-card i, .gallery-card i {
    font-size: 3em; /* Larger icon size */
    color: var(--space-cadet);
    margin-top: 10px;
    margin-right: 20px;
}

.fund-card h2, .job-card h2, .event-card h2, .gallery-card h2 {
    margin-top: 0px;
    color: var(--space-cadet);
    font-size: 2em;
    margin-bottom: 10px;
}

.fund-card p, .job-card p, .event-card p, .gallery-card p{
    font-size: 20px;
}

.fund-card a, .job-card a, .event-card a, .gallery-card a {
    display: inline-block;
    background-color: var(--red-pantone);
    color: var(--antiflash-white);
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 20px;
    transition: background-color 0.3s ease;
}

.fund-card a:hover, .job-card a:hover, .event-card a:hover, .gallery-card a:hover {
    background-color: var(--fire-engine-red);
}
     </style>
</head>
<body>
    <div class="container">
        <div class="card admin">
            <i class="fas fa-user-shield"></i>
            <h2>Admin</h2>
            <p><?php echo $adminCount; ?></p>
        </div>
        <div class="card alumni">
            <i class="fas fa-user-graduate"></i>
            <h2>Alumni</h2>
            <p><?php echo $alumniCount; ?></p>
        </div>
        <div class="card staff">
            <i class="fas fa-user-tie"></i>
            <h2>Staff</h2>
            <p><?php echo $staffCount; ?></p>
        </div>
        <div class="card course">
            <i class="fas fa-book"></i>
            <h2>Course</h2>
            <p><?php echo $courseCount; ?></p>
        </div>
        <div class="card donate">
            <i class="fas fa-dollar-sign"></i>
            <h2>Donations</h2>
            <p>Rs. <?php echo $totalDonation; ?></p>
        </div>

        <div class="job-card">
            <div>
                <h2>Job Posting</h2>
                <a href="job.php" class="btn">View all</a>
            </div>
            <div>
                <i class="fas fa-briefcase fa-3x"></i>
                <p><?php echo $jobCount; ?> Jobs</p>
            </div>
        </div>

        <div class="event-card">
            <div>
                <h2>Events</h2>
                <a href="event.php" class="btn">View all</a>
            </div>
            <div>
                <i class="fas fa-calendar-alt fa-3x"></i>
                <p><?php echo $eventCount; ?> Events</p>
            </div>
        </div>

        <div class="fund-card">
            <div>
                <h2>Fund Raising</h2>
                <a href="fund.php" class="btn">View all</a>
            </div>
            <div>
                <i class="fas fa-hand-holding-usd fa-3x"></i>
                <p><?php echo $fundCount; ?> Funds</p>
            </div>
        </div>

        <!-- Gallery Cards -->
        <div class="gallery-card">
            <div>
                <h2>Gallery Item </h2>
                <a href="#" class="btn">View All</a>
            </div>
            <div>
                <i class="fas fa-images fa-3x"></i>
                <p><?php echo $galleryCount; ?> Images</p>
            </div>
        </div>

    </div>
</body>
</html>
