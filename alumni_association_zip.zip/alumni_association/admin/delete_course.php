<?php
    include('../home/db_connection.php');
    if(isset($_GET['course-id'])){
        $id = $_GET['course-id'];
        mysqli_query($con, "DELETE FROM course WHERE id=$id");
        echo "<script>
        alert('Course Deleted!');
        window.location.href='./course.php';
        </script>";
    }
?>