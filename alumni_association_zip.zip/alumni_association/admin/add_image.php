<?php
    include("../home/db_connection.php");
    include("../actions/upload_img.php");
    // Count total files
    $countfiles = count($_FILES['images']['name']);

    // Looping all files
    for($i=0;$i<$countfiles;$i++) {
        $filename = $_FILES['images']['name'][$i];

        // Upload file
        $target_dir = "../images/gallery/";
        $image_name = $_FILES['images']['name'][$i];
        $tmp_name = $_FILES["images"]["tmp_name"][$i];
        $size = $_FILES["images"]["size"][$i];
        $image = upload_img($target_dir, $image_name, $tmp_name, $size);
        // Insert into database
        if($image == $image_name){
            $sql = "INSERT INTO gallery  VALUES ('','$filename')";
            if ($con->query($sql) === TRUE) {
            } else {
                echo "Error: " . $sql . "<br>" . $con->error;
            }
        echo "<script>alert('File uploaded and inserted into database successfully.')</script>";      
        }
        else{
            echo "<script>alert('$image');</script>";
        }
        
    }
    echo "<script>
        window.location.href='./event.php';
        </script>";
?>

