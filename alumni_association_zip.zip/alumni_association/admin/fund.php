<?php
include('../home/db_connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fund Management</title>
    <link rel="stylesheet" href="fund.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container">
        <div class="top-area">
            <h2>Add a New Fund</h2>
            <form action="add_fund.php" method="POST">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required>
                
                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="4" required></textarea>
                
                <button type="submit">Add Fund</button>
            </form>
        </div>
        <div class="bottom-area">
            <h2>Available Funds</h2>
            <div class="fund-cards">
                <?php
                $sql = "SELECT * FROM fund";
                $result = mysqli_query($con, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<div class='fund-card'>";
                        echo "<h3>" . $row['title'] . "</h3>";
                        echo "<p>" . $row['description'] . "</p>";
                        echo "<button class='delete-btn' onclick='deleteFund(" . $row['id'] . ")'>Delete</button>";
                        echo "<button class='view-btn' onclick='openModal(" . $row['id'] . ")'>View Donations</button>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No funds available</p>";
                }
                ?>
            </div>
        </div>
    </div>

    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Donations List</h2>
            <div id="donationDetails">
                <!-- Donation details content will be populated dynamically via JavaScript -->
            </div>
        </div>
    </div>

    <script>
               function openModal(fundId) {
            var modal = document.getElementById("myModal");
            modal.style.display = "block";
            
            // Fetch job details from server using AJAX
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var donationDetails = JSON.parse(this.responseText);
                    // Populate modal with job details
                    document.getElementById("donationDetails").innerHTML =
                        '<ul>' +
                        donationDetails.members.map(member =>
                            '<li>' + member.name + ' - Email: ' + member.email + '</li>'
                        ).join('') +
                        '</ul>';
                }
            };
            xhttp.open("GET", "get_donations.php?id=" + fundId, true);
            xhttp.send();
        }

        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }

        function deleteFund(fundId) {
            if(confirm("Are you sure you want to delete this fund?")) {
                window.location.href = "delete_fund.php?fund_id=" + fundId;
            }
        }
    </script>
</body>
</html>
