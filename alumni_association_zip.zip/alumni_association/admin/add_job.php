<?php
    include("../home/db_connection.php");
    include('../actions/upload_img.php');

    session_start();
    $user_id = $_SESSION['id'];

        $job_title = $_POST["job_title"];
        $job_description = $_POST["job_description"];
        $job_date = $_POST["job_date"];
        $job_location = $_POST["job_location"];
        $qualification = $_POST["qualification"];
        $experience = $_POST["experience"];
        $contact = $_POST["contact"];
            // Handle file upload
        $target_dir = "../images/job_images/";
        $image_name = $_FILES["image_upload"]["name"];
        $tmp_name = $_FILES["image_upload"]["tmp_name"];
        $size = $_FILES["image_upload"]["size"];
        $image = upload_img($target_dir, $image_name, $tmp_name, $size);

        $sql = "INSERT INTO job VALUES('',$user_id,'$job_title','$job_description','$qualification','$experience','$job_location','$job_date','$contact','$image')";
        mysqli_query($con, $sql);
        echo "<script>
        alert('Job Posted!');
        window.location.href='./job.php';
        </script>";

?>
