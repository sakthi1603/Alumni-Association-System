<?php include ('../actions/logout.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="profile">
                <img src="../images/log_admin.jpg" alt="Admin Profile" class="profile-img">
                <h3 class="admin-name">Admin Name</h3>
            </div>
            <nav class="menu">
                <ul>
                    <li><a href="home.php" id="home-link"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="../actions/search_alumni.php" id="search-link"><i class="fas fa-graduation-cap"></i> Alumni</a></li>
                    <li><a href="../actions/search_staff.php" id="search-link"><i class="fas fa-user-tie"></i> Staff</a></li>
                    <li><a href="event.php" id="events-link"><i class="fas fa-calendar-alt"></i> Events</a></li>
                    <li><a href="job.php" id="job-link"><i class="fas fa-briefcase"></i> Job</a></li>
                    <li><a href="course.php" id="course-link"><i class="fas fa-book"></i> Course</a></li>
                    <li><a href="fund.php" id="fund-link"><i class="fas fa-dollar-sign"></i> Fund</a></li>
                    <li><a href="forum.php" id="forum-link"><i class="fas fa-comments"></i> Forum</a></li>
                    <li><a href="gallery.php" id="gallery-link"><i class="fas fa-image"></i> Gallery</a></li>
                </ul>
            </nav>
            <a href="?logout"><i class="fas fa-sign-out-alt"></i> Logout</a>

        </div>
        <div class="content">
            <iframe name="content-frame" id="content-frame" src="home.php"></iframe>
        </div>
    </div>

    <script>
        // Get all menu links
        const menuLinks = document.querySelectorAll('.menu a');

        // Loop through each menu link
        menuLinks.forEach(link => {
            // Add click event listener to each link
            link.addEventListener('click', function(event) {
                // Prevent default behavior of link
                event.preventDefault();
                
                // Get the href attribute value of the clicked link
                const pageUrl = this.getAttribute('href');
                
                // Set the src attribute of the iframe to the clicked link's href
                document.getElementById('content-frame').src = pageUrl;
            });
        });
    </script>
</body>
</html>
