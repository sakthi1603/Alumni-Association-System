<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Gallery</title>
    <link rel="stylesheet" href="gallery.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container">
        <div class="top-area">
            <h2>Add Photos to Gallery</h2>
            <form action="add_image.php" method="POST" enctype="multipart/form-data">
                <label for="images">Upload Images:</label>
                <input type="file" id="images" name="images[]" multiple required>
                <button type="submit">Upload Images</button>
            </form>
        </div>
        <div class="bottom-area">
            <h2>Gallery</h2>
            <div class="gallery">
                <?php
                include('../home/db_connection.php');
                $sql = "SELECT * FROM gallery ORDER BY id DESC";
                $result = mysqli_query($con, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<div class='image-card'>";
                        echo "<img src='../images/gallery/" . $row['filename'] . "' alt='Gallery Image'>";
                        echo "<a href='delete_image.php?image-id=" . $row['id'] . "' class='delete-btn'>Delete</a>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No images available</p>";
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>
