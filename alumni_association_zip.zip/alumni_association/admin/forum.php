<?php
include('../home/db_connection.php');

// Function to handle new message submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $message = $_POST['message'];

    $sql = "INSERT INTO forum (user, content, date) VALUES ('$username', '$message', NOW())";
    mysqli_query($con, $sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Board</title>
    <link rel="stylesheet" href="forum.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container">
        <div class="top-area">
            <h2>Leave a Reply</h2>
            <form action="" method="POST">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                
                <label for="message">Message:</label>
                <textarea id="message" name="message" rows="4" required placeholder="Write your message here"></textarea>
                
                <button type="submit">Post</button>
            </form>
        </div>
        <div class="bottom-area">
            <h2>Messages</h2>
            <div class="message-cards">
                <?php
                $sql = "SELECT * FROM forum ORDER BY date DESC";
                $result = mysqli_query($con, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<div class='message-card'>";
                        echo "<div class='message-header'>";
                        echo "<span class='username'>" . htmlspecialchars($row['user']) . "</span>";
                        echo "<span class='timestamp'>" . $row['date'] . "</span>";
                        echo "</div>";
                        echo "<p class='message-content'>" . nl2br(htmlspecialchars($row['content'])) . "</p>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No messages yet.</p>";
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>
