<?php
session_start();
include '../home/db_connection.php'; // Make sure to include your database connection file

$user_id = $_SESSION['id'];
$amount = $_POST['amount'];
$payment_method = $_POST['payment_method'];
$fund_id = $_POST['fund_id'];

$query = "INSERT INTO donations VALUES ('', $fund_id, $user_id, '$payment_method', $amount)";
mysqli_query($con, $query);

echo 'Donation successful';
?>
