<?php
    include('../home/db_connection.php');
    session_start();
    $user = $_SESSION['user'];
    $user_id = $_SESSION['id'];
    $user_type = $_SESSION['type'];

    $totalDonation = 0;
    $totalEvents = 0;
    $totalJobs = 0;

    $query = "SELECT COUNT(*) AS total_rows FROM event_register WHERE user_id = $user_id";
    // Perform the query
    $result = mysqli_query($con, $query);

    $event = mysqli_fetch_assoc($result);
    $totalEvents = $event['total_rows'];


    $query = "SELECT SUM(amount) AS total_amount FROM donations WHERE user_id = $user_id";
    $result = mysqli_query($con, $query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $totalDonation = $row['total_amount'];
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Dashboard</title>
    <link rel="stylesheet" href="home.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<body>
    <div class="container">
        <div class="welcome-card">
            <div class="overlay">
                <h1>Welcome back, <?php echo $user;?>!</h1>
                <!-- <p>Department: [User Department]</p> -->
            </div>
        </div>
        <div class="cards-section">
            <div class="card">
                <i class="fas fa-calendar-alt"></i>
                <h2>Event Registered</h2>
                <p><?php echo $totalEvents ; ?></p>
            </div>
        <?php
            if($user_type == 'alumni'){
                $query = "SELECT COUNT(*) AS total_rows FROM job_application  WHERE user_id = $user_id";
                // Perform the query
                $result = mysqli_query($con, $query);

                $job = mysqli_fetch_assoc($result);
                $totalJobs = $job['total_rows'];
        ?>
            <div class="card">
                <i class="fas fa-briefcase"></i>
                <h2>Jobs Applied</h2>
                <p><?php echo $totalJobs ; ?></p>         
            </div>
        <?php
            }
            else{
                $query = "SELECT COUNT(*) AS total_rows FROM job  WHERE user_id = $user_id";
                // Perform the query
                $result = mysqli_query($con, $query);

                $job = mysqli_fetch_assoc($result);
                $JobPosted = $job['total_rows'];
        ?>
            <div class="card">
                <i class="fas fa-briefcase"></i>
                <h2>Jobs Posted</h2>
                <p><?php echo $JobPosted ; ?></p>         
            </div>
        <?php
            }
        ?>
            <div class="card">
                <i class="fas fa-dollar-sign"></i>
                <h2>Total Donation</h2>
                <p>Rs. <?php echo $totalDonation; ?></p>
            </div>
        </div>

    </div>
</body>
</html>
