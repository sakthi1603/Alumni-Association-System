<?php
session_start();
$user_id = $_SESSION['id'];
include '../home/db_connection.php';

$type = $_POST['type'];
$query = "";

if ($type == 'all') {
    $query = "SELECT * FROM event ORDER BY id DESC";
} elseif ($type == 'registered') {
    $query = "SELECT e.* FROM event e INNER JOIN event_register r ON e.id = r.event_id WHERE r.user_id = ?";
} elseif ($type == 'search') {
    $search_query = $_POST['query'];
    $query = "SELECT * FROM event WHERE title LIKE ? ORDER BY id DESC";
    $search_query = "%$search_query%";
}

$stmt = $con->prepare($query);

if ($type == 'registered') {
    $stmt->bind_param("i", $user_id);
} elseif ($type == 'search') {
    $stmt->bind_param("s", $search_query);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $event_id = $row['id'];

    $registered_query = "SELECT * FROM event_register WHERE event_id = ? AND user_id = ?";
    $registered_stmt = $con->prepare($registered_query);
    $registered_stmt->bind_param("ii", $event_id, $user_id);
    $registered_stmt->execute();
    $registered_result = $registered_stmt->get_result();

    $is_registered = $registered_result->num_rows > 0;
    $button_text = $is_registered ? "Registered" : "Register";

    echo "
    <div class='event-card'>
        <img src='../images/event_images/{$row['image']}' alt='Event Image'>
        <h3>{$row['title']}</h3>
        <p>{$row['description']}</p>
        <p>Date: {$row['datetime']}</p>
        <button class='register-btn' data-event-id='{$event_id}' " . ($is_registered ? "disabled" : "") . ">{$button_text}</button>
    </div>";
}
$stmt->close();
$con->close();
?>
