<?php
// Assuming $con is your MySQLi connection resource and user ID is stored in session
session_start();
$user_id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Page</title>
    <link rel="stylesheet" href="job.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container">
        <div class="top-section">
            <div class="top-left">
                <button id="all-jobs-btn">All Jobs</button>
                <button id="registered-jobs-btn">Applied Jobs</button>
                <button id="my-jobs-btn">My Jobs</button>
                <button id="add-job-btn">Post job</button>
            </div>
            <div class="top-right">
                <input type="text" id="search-input" placeholder="Search job...">
                <button id="search-btn">Search</button>
            </div>
        </div>
        <div class="bottom-section" id="jobs-list">
            <!-- Events will be displayed here -->
        </div>
    </div>

    <!-- Modal for Adding Event -->
    <div id="add-job-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Post Job</h2>
            <form action='add_job.php' method='POST' enctype="multipart/form-data" id="add-job-form">
                <label for="job_title">Job Title:</label>
                <input type="text" id="job_title" name="job_title" required>
    
                <label for="event_description">Description:</label>
                <textarea id="job_description" name="job_description" rows="4" required></textarea><br>
                
                <label for="event_date">Held on:</label>
                <input type="date" id="date" name="job_date" required><br><br>
                
                <label for="event_location">Location:</label>
                <input type="text" id="job_location" name="job_location" required>
                
                <label for="event_timing">Qualification:</label>
                <input type="text" id="qualification" name="qualification" required>

                <label for="event_timing">Experience:</label>
                <input type="text" id="experience" name="experience" required>

                <label for="event_timing">Contact:</label>
                <input type="text" id="contact" name="contact" required>
                
                <label for="image_upload">Upload Image:</label>
                <input type="file" id="image_upload" name="image_upload" accept="image/*" required>

                <button type="submit">Publish Job</button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Load all events by default
            loadJobs('all');

            // Event listeners for buttons
            document.getElementById('all-jobs-btn').addEventListener('click', function() {
                loadJobs('all');
            });

            document.getElementById('registered-jobs-btn').addEventListener('click', function() {
                loadJobs('registered');
            });

            document.getElementById('my-jobs-btn').addEventListener('click', function() { // Event listener for My Job button
                loadJobs('my'); // Load jobs posted by the user
            });

            document.getElementById('search-btn').addEventListener('click', function() {
                const query = document.getElementById('search-input').value;
                loadJobs('search', query);
            });

            // Add Event Modal
            var modal = document.getElementById("add-job-modal");
            var btn = document.getElementById("add-job-btn");
            var span = document.getElementsByClassName("close")[0];

            btn.onclick = function() {
                modal.style.display = "block";
            }

            span.onclick = function() {
                modal.style.display = "none";
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }

            // Function to load events
            function loadJobs(type, query = '') {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'load_job.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status == 200) {
                        document.getElementById('jobs-list').innerHTML = this.responseText;

                        // Add event listeners for the register buttons
                        document.querySelectorAll('.register-btn').forEach(button => {
                            button.addEventListener('click', function() {
                                const jobId = this.getAttribute('data-job-id');
                                registerJob(jobId, this);
                            });
                        });
                    }
                };
                xhr.send(`type=${type}&query=${query}`);
            }

            function registerJob(jobId, button) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'apply_job.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status == 200) {
                        if (this.responseText.trim() === 'success') {
                            button.textContent = 'Applied';
                            button.disabled = true;
                        } else {
                            alert('Registration failed. Please try again.');
                        }
                    }
                };
                xhr.send(`job_id=${jobId}`);
            }
        });
    </script>
</body>
</html>
