<?php
session_start();
include '../home/db_connection.php'; // Make sure to include your database connection file

$user_id = $_SESSION['id'];
$type = $_POST['type'];
$query = "";

if ($type == 'all') {
    $query = "SELECT * FROM fund";
} else if ($type == 'donated') {
    $query = "SELECT * FROM fund f INNER JOIN donations d ON f.id = d.fund_id WHERE d.user_id = $user_id";
}

$result = mysqli_query($con, $query);

while ($row = mysqli_fetch_assoc($result)) {
    $fund_id = $row['id'];
    $donated_query = "SELECT * FROM donations WHERE user_id = $user_id AND fund_id = $fund_id";
    $donated_result = mysqli_query($con, $donated_query);
    $donated = mysqli_num_rows($donated_result) > 0;

    echo '<div class="fund-card">';
    echo '<h3>' . $row['title'] . '</h3>';
    echo '<p>' . $row['description'] . '</p>';
    
    if ($donated) {
        echo '<button disabled>Donated</button>';
    } else {
        echo '<button onclick="openModal(' . $row['id'] . ')">Donate</button>';
    }
    
    echo '</div>';
}
?>
