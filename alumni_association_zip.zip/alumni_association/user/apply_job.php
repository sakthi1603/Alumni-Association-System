<?php
session_start();
include '../home/db_connection.php';

$user_id = $_SESSION['id'];
$job_id = $_POST['job_id'];

// Check if the user is already registered
$check_query = "SELECT * FROM job_application WHERE job_id = ? AND user_id = ?";
$check_stmt = $con->prepare($check_query);
$check_stmt->bind_param("ii", $job_id, $user_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    echo "already_registered";
} else {
    $insert_query = "INSERT INTO job_application VALUES ('',?, ?)";
    $insert_stmt = $con->prepare($insert_query);
    $insert_stmt->bind_param("ii", $job_id, $user_id);

    if ($insert_stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }
}

$check_stmt->close();
$insert_stmt->close();
$con->close();
?>
