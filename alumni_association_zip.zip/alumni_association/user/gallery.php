<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Gallery</title>
    <style>
        body {
            margin: 0;
            padding: 0;
        }
        .gallery-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }
        .gallery-item {
            margin: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            width: 300px; /* Set width of gallery item */
            height: auto; /* Set height of gallery item */
            cursor: pointer; /* Add cursor pointer for clickable effect */
        }
        .gallery-item:hover {
            transform: scale(1.05);
        }
        .gallery-item img {
            width: 100%;
            height: 100%; /* Set image height to fill parent container */
            object-fit: cover; /* Maintain aspect ratio and cover entire container */
        }

        /* Modal styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 9999; /* Sit on top */
            padding-top: 30px; /* Location of the modal */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
        }

        .modal-content {
            margin: auto;
            display: block;
            width: 100%;
            max-width: 700px; /* Max width */
        }

        /* Close button */
        .close {
            color: #fff;
            position: absolute;
            top: 15px;
            right: 35px;
            font-size: 40px;
            font-weight: bold;
            transition: 0.3s;
            cursor: pointer;
        }

        .close:hover,
        .close:focus {
            color: #bbb;
            text-decoration: none;
            cursor: pointer;
        }

        /* Responsive image */
        .modal-content img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="gallery-container">
        <?php
        // Database connection
        include('../home/db_connection.php');

        // Fetch images from the database
        $sql = "SELECT * FROM gallery ORDER BY id DESC";
        $result = $con->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<div class='gallery-item' onclick='openModal(\"../images/gallery/" . $row["filename"] . "\", \"" . $row["id"] . "\")'>";
                echo "<img src='../images/gallery/" . $row["filename"] . "' alt='image " . $row["id"] . "'>";
                echo "</div>";
            }
        } else {
            echo "0 results";
        }
        $con->close();
        ?>
    </div>

    <!-- The Modal -->
    <div id="myModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="modalImg">
    </div>

    <script>
        // Open the modal
        function openModal(imgSrc, alt) {
            var modal = document.getElementById("myModal");
            var modalImg = document.getElementById("modalImg");

            modal.style.display = "block";
            modalImg.src = imgSrc;
            modalImg.alt = alt;
        }

        // Close the modal
        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }
    </script>
</body>
</html>
