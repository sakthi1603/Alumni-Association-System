<?php
// Assuming $con is your MySQLi connection resource and user ID is stored in session
session_start();
$user_id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Page</title>
    <link rel="stylesheet" href="event.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container">
        <div class="top-section">
            <div class="top-left">
                <button id="all-events-btn">All Events</button>
                <button id="registered-events-btn">Registered Events</button>
            </div>
            <div class="top-right">
                <input type="text" id="search-input" placeholder="Search events...">
                <button id="search-btn">Search</button>
            </div>
        </div>
        <div class="bottom-section" id="events-list">
            <!-- Events will be displayed here -->
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Load all events by default
            loadEvents('all');

            // Event listeners for buttons
            document.getElementById('all-events-btn').addEventListener('click', function() {
                loadEvents('all');
            });

            document.getElementById('registered-events-btn').addEventListener('click', function() {
                loadEvents('registered');
            });

            document.getElementById('search-btn').addEventListener('click', function() {
                const query = document.getElementById('search-input').value;
                loadEvents('search', query);
            });

            // Function to load events
            function loadEvents(type, query = '') {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'load_events.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status == 200) {
                        document.getElementById('events-list').innerHTML = this.responseText;

                        // Add event listeners for the register buttons
                        document.querySelectorAll('.register-btn').forEach(button => {
                            button.addEventListener('click', function() {
                                const eventId = this.getAttribute('data-event-id');
                                registerEvent(eventId, this);
                            });
                        });
                    }
                };
                xhr.send(`type=${type}&query=${query}`);
            }

            function registerEvent(eventId, button) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'register_event.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status == 200) {
                        if (this.responseText.trim() === 'success') {
                            button.textContent = 'Registered';
                            button.disabled = true;
                        } else {
                            alert('Registration failed. Please try again.');
                        }
                    }
                };
                xhr.send(`event_id=${eventId}`);
            }
        });
    </script>
</body>
</html>
