<?php
session_start();
$user_id = $_SESSION['id'];
include '../home/db_connection.php';

$type = $_POST['type'];
$query = "";

if ($type == 'all') {
    $query = "SELECT * FROM job ORDER BY id DESC";
} elseif ($type == 'registered') {
    $query = "SELECT * FROM job j INNER JOIN job_application a ON j.id = a.job_id WHERE a.user_id = ?";
} elseif ($type == 'search') {
    $search_query = $_POST['query'];
    $query = "SELECT * FROM job WHERE title LIKE ? ORDER BY id DESC";
    $search_query = "%$search_query%";
} elseif ($type == 'my') {
    $query = "SELECT * FROM job WHERE user_id = ?";
}

$stmt = $con->prepare($query);

if ($type == 'registered' || $type == 'my') {
    $stmt->bind_param("i", $user_id);
} elseif ($type == 'search') {
    $stmt->bind_param("s", $search_query);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $job_id = $row['id'];

    if ($type == 'my') {
        echo "
        <div class='job-card'>
            <img src='../images/job_images/{$row['banner']}' alt='Job Image'>
            <h3>{$row['title']}</h3>
            <p>{$row['description']}</p>
            <p>Location: {$row['location']} Date: {$row['held_on']}</p>
            <p>Experience: {$row['level']} Qualification: {$row['qualification']}</p>
            <p>Contact: {$row['contact']}</p>
            <a href='delete_job.php?job-id={$job_id}' class='delete-btn'>Delete</a>
        </div>";
    } else {
        $registered_query = "SELECT * FROM job_application WHERE job_id = ? AND user_id = ?";
        $registered_stmt = $con->prepare($registered_query);
        $registered_stmt->bind_param("ii", $job_id, $user_id);
        $registered_stmt->execute();
        $registered_result = $registered_stmt->get_result();

        $is_registered = $registered_result->num_rows > 0;
        $button_text = $is_registered ? "Applied" : "Apply";

        echo "
        <div class='job-card'>
            <img src='../images/job_images/{$row['banner']}' alt='Job Image'>
            <h3>{$row['title']}</h3>
            <p>{$row['description']}</p>
            <p>Location: {$row['location']} Date: {$row['held_on']}</p>
            <p>Experience: {$row['level']} Qualification: {$row['qualification']}</p>
            <p>Contact: {$row['contact']}</p>
            <button class='register-btn' data-job-id='{$job_id}' " . ($is_registered ? "disabled" : "") . ">{$button_text}</button>
        </div>";
    }
}
$stmt->close();
$con->close();
?>
