<?php
session_start();
$user_id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funds Page</title>
    <link rel="stylesheet" href="fund.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="container">
        <div class="top-section">
            <div class="top-left">
                <button id="all-funds-btn">All Funds</button>
                <button id="donated-funds-btn">Donated</button>
            </div>
        </div>
        <div class="bottom-section" id="funds-list">
            <!-- Funds will be displayed here -->
        </div>
    </div>

    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Donate</h2>
            <form id="donate-form">
                <label for="amount">Amount:</label>
                <input type="number" id="amount" name="amount" required>
                <label for="payment-method">Payment Method:</label>
                <select id="payment-method" name="payment_method" required>
                    <option value="credit_card">Credit Card</option>
                    <option value="paypal">PayPal</option>
                    <option value="bank_transfer">Bank Transfer</option>
                </select>
                <input type="hidden" id="fund-id" name="fund_id">
                <button type="submit">Donate</button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadFunds('all');

            document.getElementById('all-funds-btn').addEventListener('click', function() {
                loadFunds('all');
            });

            document.getElementById('donated-funds-btn').addEventListener('click', function() {
                loadFunds('donated');
            });

            document.getElementById('donate-form').addEventListener('submit', function(e) {
                e.preventDefault();
                // Add code to handle the form submission and save to database
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'donate.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status == 200) {
                        alert('Donation successful');
                        closeModal();
                        loadFunds('all');
                    }
                };
                const amount = document.getElementById('amount').value;
                const paymentMethod = document.getElementById('payment-method').value;
                const fundId = document.getElementById('fund-id').value;
                xhr.send(`amount=${amount}&payment_method=${paymentMethod}&fund_id=${fundId}`);
            });

            window.openModal = function(fundId) {
                document.getElementById('fund-id').value = fundId;
                document.getElementById('modal').style.display = 'block';
            };

            function loadFunds(type) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'load_funds.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status == 200) {
                        document.getElementById('funds-list').innerHTML = this.responseText;
                    }
                };
                xhr.send(`type=${type}`);
            }

            window.closeModal = function() {
                document.getElementById('modal').style.display = 'none';
            };
        });
    </script>
</body>
</html>
