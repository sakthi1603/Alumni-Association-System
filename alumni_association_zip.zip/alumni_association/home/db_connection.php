<?php
$con = mysqli_connect('localhost','root','','alumni_association');
if(!$con){
    die(mysqli_error($con));
}
?>