<?php
    include("./db_connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Association</title>
    <!-- css link -->
    <link rel="stylesheet" href="style.css?v=<?php echo time();?>">

    <!-- boxicons link -->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>

    <!-- google font link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
</head>
<body>
   <?php 
        include('header.php'); 
        if(isset($_GET['search-alumni'])){
            include('../actions/search_alumni.php');
        }
        else if(isset($_GET['search-staff'])){
            include('../actions/search_staff.php');
        }
        else{
    ?>
    <div class="container">
        <div class="welcome-message">
            <h1>Welcome to the Alumni Association</h1>
            <p>We are delighted to have you here. Explore and enjoy!</p>
        </div>
    </div>
    <section class="about-us">
        <div class="container-abt">
            <h2>About Us</h2>
            <div class="content">
                <img src="../images/infra.jpg" alt="Our Team" class="team-photo">
                <div class="text">
                    <p>At Alumni Association, we are dedicated to fostering a lifelong relationship between our alma mater and its alumni. Our mission is to create a network that connects, supports, and engages alumni through various programs, events, and initiatives.</p>
                    <p>Thank you for visiting our site. We look forward to connecting with you and exploring how we can work together to achieve great things!</p>
                    <a href="https://kmcpgs.py.gov.in/" target="_blank" class="learn-more-button">Learn More</a>
                </div>
            </div>
        </div>
    </section>
    <section class="upcoming-events">
        <h1>Upcoming Events</h1>
<?php
    $sql = "SELECT * FROM event ORDER BY id DESC";
    $res = mysqli_query($con, $sql);
    $counter = 1;
    if(mysqli_num_rows($res)>0){
        foreach($res as $row){
            if($counter <= 2){
            $no = mysqli_num_rows(mysqli_query($con, "SELECT * FROM event_register WHERE event_id = ".$row['id']));
?>
        <div class="event">
            <div class="event-image">
                <img src="../images/event_images/<?php echo $row['image'];?>" alt="Event 1">
            </div>
            <div class="event-details">
                <h3><?php echo $row['title'];?></h3>
                <p><?php echo $row['description'];?></p>
                <p><?php echo "Date: ".$row['datetime']." Location: ".$row['location'];?></p>
                <a href="../actions/login.php" class="btn">Register Now</a>
            </div>
        </div>
<?php
        }
        $counter += 1;
    }
    }
?>
    </section>
    <section class="explore-section">
        <div class="overlay"></div>
        <div class="explore-content">
            <h2>Explore</h2>
            <div class="explore-boxes">
                <div class="explore-box">
                    <a href="../actions/register.php" class="explore-link">Register</a>
                </div>
                <div class="explore-box">
                    <a href="../actions/login.php" class="explore-link">Explore</a>
                </div>
                <div class="explore-box">
                    <a href="?search-alumni" class="explore-link">Alumni</a>
                </div>
                <div class="explore-box">
                    <a href="?search-staff" class="explore-link">Staff</a>
                </div>
            </div>
        </div>
    </section>
    <section class="job-postings">
        <h1>Job Postings</h1>
<?php
    $sql = "SELECT * FROM job ORDER BY id DESC";
    $res = mysqli_query($con, $sql);
    $counter = 1;
    if(mysqli_num_rows($res)>0){
        foreach($res as $row){
            if($counter <= 2){
            $no = mysqli_num_rows(mysqli_query($con, "SELECT * FROM event_register WHERE event_id = ".$row['id']));
?>
        <div class="event">
            <div class="event-image">
                <img src="../images/job_images/<?php echo $row['banner'];?>" alt="Event 1">
            </div>
            <div class="event-details">
                <h3><?php echo $row['title'];?></h3>
                <p><?php echo $row['description'];?></p>
                <p><?php echo "Date: ".$row['held_on']." Location: ".$row['location']." Contact: ".$row['contact'];?></p>
                <a href="../actions/login.php" class="btn">Register Now</a>
            </div>
        </div>
<?php
        }
        $counter += 1;
    }
    }
?>
    </section>
    <section class="spotlight">
        <h2 class="spotlight-heading">In the Spotlight</h2>
        <div class="spotlight-section">
            <div class="spotlight-images">
<?php
    $sql = "SELECT * FROM gallery ORDER BY id DESC";
    $res = mysqli_query($con, $sql);
    $counter = 1;
    if(mysqli_num_rows($res)>0){
        foreach($res as $row){
            if($counter <= 6){
            $no = mysqli_num_rows(mysqli_query($con, "SELECT * FROM event_register WHERE event_id = ".$row['id']));
?>
        <div class="image-wrapper">
            <img src="../images/gallery/<?php echo $row["filename"];?>" alt="Image 1">
        </div>
<?php
        }
        $counter += 1;
    }
    }
?>
                <!-- Add more image wrappers as needed -->
            </div>
        </div>
    </section>
    <?php
        $sql = "SELECT title, description FROM fund LIMIT 4";
        $result = mysqli_query($con, $sql);
        
        $funds = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $funds[] = $row;
        }
    ?>
    <section class='donate'>
        <h2 class='donate-heading'>Donate</h2>
        <div class="donation-section">
            <?php foreach ($funds as $fund): ?>
                <div class="donation-card">
                    <h3><?php echo htmlspecialchars($fund['title']); ?></h3>
                    <p><?php echo htmlspecialchars($fund['description']); ?></p>
                    <a href="../actions/login.php" class="donate-btn">Donate</a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <?php
        include('footer.php');
        }
    
   ?>
    
    
    <!-- js file link -->
</body>
</html>