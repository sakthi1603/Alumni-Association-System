-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2024 at 01:52 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alumni_association`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `profile` varchar(40) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `contact`, `profile`, `password`) VALUES
(101, 'admin', 'admin@admin.com', '895345', '003.jpg', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `martial_status` varchar(20) NOT NULL,
  `course_id` int(50) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `year_of_passing` year(4) NOT NULL,
  `job_title` varchar(20) NOT NULL,
  `job_location` varchar(30) NOT NULL,
  `profile` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`id`, `name`, `gender`, `martial_status`, `course_id`, `contact`, `email`, `address`, `year_of_passing`, `job_title`, `job_location`, `profile`, `password`) VALUES
(2222608, 'Bala', 'male', 'single', 5, '8734092343', 'abirami6382@gmail.com', 'No.35, Bahour', '2024', 'developer', 'Chennai', '001.jpg', 'balraj'),
(2222645, 'Sathiyaseelan', 'male', 'single', 5, '8056989375', 'sathiyaseelan1603@gmail.com', 'No.43 Bahour', '2022', 'Designer', 'Chennai', '002.jpg', 'sathiya');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `course` varchar(20) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `duration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course`, `branch`, `duration`) VALUES
(1, 'MA', 'Tamil', 2),
(2, 'MA', 'English', 2),
(3, 'MA', 'Economics', 2),
(4, 'MA', 'French', 2),
(5, 'MSc', 'Computer Science', 2),
(6, 'MSc', 'Mathematics', 2),
(7, 'MSc', 'Chemistry', 2),
(8, 'MSc', 'Physics', 2),
(20, 'MSc', 'Zoology', 2);

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `fund_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `method` varchar(25) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `fund_id`, `user_id`, `method`, `amount`) VALUES
(1, 1, 2222645, 'credit_card', 2000),
(2, 1, 1, 'bank_transfer', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(150) NOT NULL,
  `datetime` datetime NOT NULL,
  `location` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `title`, `description`, `datetime`, `location`, `image`) VALUES
(1, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\nopportunity to the participants to showcase their\ninnovative ideas as an exhibit and make it as a startup', '2024-04-25 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(2, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-25 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(3, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-25 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(4, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-25 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(5, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-25 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(6, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-21 00:00:00', 'Chennai', 'Screenshot 2024-03-31 195032.png'),
(7, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-28 00:00:00', 'Chennai', 'Screenshot 2024-03-31 195032.png'),
(8, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an opportunity to the participants to showcase their innovative ideas as an exhibit and make it as a startup', '2024-04-29 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(9, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an opportunity to the participants to showcase their innovative ideas as an exhibit and make it as a startup', '2024-04-30 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(10, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-28 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(11, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-23 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(12, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-24 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(13, 'Intercolleigate innovation competition', 'The aim of this programme is to provide an\r\nopportunity to the participants to showcase their\r\ninnovative ideas as an exhibit and make it as a startup', '2024-04-22 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(14, 'Intercolleigate innovation competition', 'Heloo', '2024-05-01 00:00:00', 'KMGIPSR', 'Screenshot 2024-03-31 195032.png'),
(15, 'Convocation', '2019-2022 Batch convocation ', '2024-05-10 00:00:00', 'Indhra Gandhi Stadium', 'img1.jpeg'),
(16, 'Convocation', '2019-2022 Batch convocation', '2024-06-20 18:30:00', 'Stadium', 'img1.jpeg'),
(17, 'Convocation', '2019-2022 Batch convocation', '2024-06-19 18:30:00', 'Stadium', 'img1.jpeg'),
(19, 'Convocation', '2019-2022 Batch convocation', '2024-06-18 18:30:00', 'Stadium', 'img1.jpeg'),
(20, 'Convocation', '2019-2022 Batch convocation', '2024-06-18 18:30:00', 'Stadium', 'img1.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `event_register`
--

CREATE TABLE `event_register` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `event_register`
--

INSERT INTO `event_register` (`id`, `event_id`, `user_id`) VALUES
(1, 14, 2222608),
(2, 12, 2222608),
(3, 20, 2222645),
(4, 14, 2222645),
(5, 19, 2222645);

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE `forum` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `content` varchar(500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `forum`
--

INSERT INTO `forum` (`id`, `user`, `content`, `date`) VALUES
(1, 'Saratha', 'The event was really wonderful', '2024-04-12 18:30:00'),
(2, 'Mary Catherine', 'Yes I enjoyed it!', '2024-04-12 18:30:00'),
(3, 'bala', 'thoughtful event\r\n', '2024-04-23 18:30:00'),
(4, 'Sathiya', 'Thank you for the event organizers', '2024-04-25 18:30:00'),
(5, 'Saro', 'Happy to be involved', '2024-06-17 03:37:03'),
(6, 'Sathiya', 'Waiting for upcoming convocation', '2024-06-17 08:18:44');

-- --------------------------------------------------------

--
-- Table structure for table `fund`
--

CREATE TABLE `fund` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `fund`
--

INSERT INTO `fund` (`id`, `title`, `description`) VALUES
(1, 'Donate', 'Make donation to make increment in the college'),
(2, 'Convocation', 'Fund raising for convocation');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `filename`) VALUES
(1, 'event1.jpg'),
(2, 'event2.jpg'),
(3, 'event3.jpg'),
(4, 'event4.jpg'),
(5, 'event5.jpg'),
(6, 'event6.jpg'),
(7, 'event-banner.png'),
(8, 'log_admin.jpg'),
(9, 'event5.jpg'),
(10, 'event3.jpg'),
(11, 'event4.jpg'),
(13, 'hcl.jpg'),
(15, 'Screenshot 2024-03-31 195032.png'),
(17, 'img1.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `held_on` varchar(50) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `banner` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`id`, `user_id`, `title`, `description`, `qualification`, `level`, `location`, `held_on`, `contact`, `banner`) VALUES
(2, 1, 'Designer', 'Designer needed', 'Any degree', 'Fresher', 'Pondicherry', '2024-04-11', '8734672309', 'Screenshot 2024-04-08 211044.png'),
(4, 101, 'HCL-Tech', 'AI Researcher wanted', 'Any Graduate', 'Fresher', 'Madurai', '2024-05-26', '9500779658', 'hcl.jpg'),
(7, 2222645, 'TCS Hiring 2024 freshers', 'TCS Hiring 2024 freshers for different sectors', 'B.E/B.Tech/MCA/M.Sc', 'Fresher', 'Chennai', '2024-06-27', '8745324523', 'Screenshot 2024-04-08 211044.png');

-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE `job_application` (
  `id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `job_application`
--

INSERT INTO `job_application` (`id`, `job_id`, `user_id`) VALUES
(1, 2, 2222608),
(2, 3, 2222645),
(3, 4, 2222645),
(4, 2, 2222645);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from_user` int(30) NOT NULL,
  `to_user` int(30) NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT ' 1 = text , 2 = photos,3 = videos, 4 = documents ',
  `message` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `popped` tinyint(1) NOT NULL,
  `delete_flag` tinyint(1) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from_user`, `to_user`, `type`, `message`, `status`, `popped`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 1, 0, 1, 'hi', 0, 1, 0, '2024-04-24 13:03:52', '2024-04-24 13:56:45'),
(2, 1, 0, 1, 'hi', 0, 1, 0, '2024-04-24 13:04:05', '2024-04-24 13:56:45'),
(3, 1, 2222608, 1, 'hi', 0, 1, 0, '2024-04-24 13:23:03', '2024-04-24 13:40:17'),
(4, 1, 2222608, 1, 'hello', 0, 1, 0, '2024-04-24 13:36:24', '2024-04-24 13:40:17'),
(5, 2222608, 2222645, 1, 'hi', 1, 1, 0, '2024-04-24 13:40:25', '2024-04-24 14:00:30'),
(6, 2222608, 2222645, 1, 'hello', 1, 1, 0, '2024-04-24 13:42:56', '2024-04-24 14:00:30'),
(7, 2222645, 2222608, 1, 'hi bala', 1, 1, 0, '2024-04-24 14:03:18', '2024-04-24 14:15:52'),
(8, 2222645, 2222608, 1, 'Hi', 1, 1, 0, '2024-04-24 14:15:28', '2024-04-24 14:15:52'),
(9, 2222645, 2222608, 1, 'hey', 0, 0, 0, '2024-06-17 10:57:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `course_id` int(30) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `martial_status` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `profile` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `gender`, `course_id`, `contact`, `email`, `martial_status`, `address`, `profile`, `password`) VALUES
(1, 'Sathiya', 'male', 4, '8056989375', 'sathiyaseelan1603@gmail.com', 'married', 'No, 40 Bahour, Puducherry', 'image.jpg', 'Sathiya16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_register`
--
ALTER TABLE `event_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fund`
--
ALTER TABLE `fund`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_application`
--
ALTER TABLE `job_application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `event_register`
--
ALTER TABLE `event_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `forum`
--
ALTER TABLE `forum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `fund`
--
ALTER TABLE `fund`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `job_application`
--
ALTER TABLE `job_application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
