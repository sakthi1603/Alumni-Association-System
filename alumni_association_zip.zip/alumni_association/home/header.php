<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Association</title>
</head>
<body>
    <header>
    <nav class="navbar">
        <div class="navbar-left">
            <img src="../images/logo.jpg" alt="Logo" class="logo">
            <span class="title">Alumni Association</span>
        </div>
        <div class="navbar-right">
            <a href="./index.php" class="nav-link">Home</a>
            <a href="?search-alumni" class="nav-link">Alumni</a>
            <a href="?search-staff" class="nav-link">Staff</a>
            <a href="../actions/register.php" class="nav-link">Register</a>
            <a href="../actions/login.php" class="nav-link">Login</a>
        </div>
    </nav>
    </header>
</body>
</html>